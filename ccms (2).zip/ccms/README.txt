CCMS - Cloud-Based Clinic Management System
Federal Polytechnic Damaturu
============================================

This is a fully static HTML/CSS/JS build — no PHP, no MySQL,
no server required. Every module in the nav is implemented and
functional, backed by a browser-side "database" persisted to
localStorage.

HOW TO RUN
-------------------------
1. Open index.html (or login.html) directly in a browser, OR serve
   the folder with any static file server, e.g.:

     python3 -m http.server 8080

   then visit http://localhost:8080/

2. Log in with any of the 4 mock accounts (defined in js/data.js):

     Administrator:  admin@fpd.edu.ng     / Admin@1234
     Clinician:      doctor@fpd.edu.ng    / Doctor@1234
     Pharmacist:     pharmacy@fpd.edu.ng  / Pharma@1234
     Receptionist:   reception@fpd.edu.ng / Recept@1234

WHAT'S INCLUDED
-----------------------------
Root pages:
  index.html                    - Entry point, redirects to login or dashboard
  login.html                     - Login page
  dashboard.html                  - Role-aware dashboard (stats, recent
                                     patients, appointments, consultations,
                                     low stock)
  403.html                        - Access denied page

Module pages (linked from the sidebar, role-gated):
  modules/reception/register.html   - Register a new patient
  modules/reception/search.html      - Search patients + view full profile
                                        and consultation history
  modules/reception/appointment.html  - Book appointments, filter by status,
                                         mark attended/cancelled
  modules/clinician/patients.html      - Patient EHR: record a consultation
                                          (vitals, diagnosis, prescriptions)
                                          and view visit history
  modules/pharmacy/inventory.html       - Manage drug stock: add/edit/delete/
                                           restock, low-stock flags
  modules/pharmacy/pending.html          - Dispense pending prescriptions
                                            (decrements inventory automatically)
  modules/admin/users.html                - Manage staff accounts (add/edit/
                                             activate/deactivate/delete)
  modules/admin/reports.html               - Aggregate reports: patients by
                                              category, consultations by
                                              clinician, appointments by
                                              status, low stock

Shared assets:
  css/ccms.css              - Design system + all page/component styles
  js/config.js                - App constants + role colors
  js/utils.js                  - escapeHtml, date/time formatting, toasts
  js/data.js                    - Mock "database" + all CRUD helpers,
                                   persisted to localStorage (key ccms_db_v1)
  js/auth.js                     - Login/logout + session handling
                                    (sessionStorage, 30-minute inactivity
                                    timeout, role-based route guards)
  js/nav.js                       - Renders the role-based sidebar/topbar
  js/modal.js                      - Reusable modal dialog helper
  js/dashboard.js                   - Dashboard stats/tables
  js/modules/*.js                    - One script per module page above
  js/ccms.js                          - Sidebar toggle (+ mobile backdrop),
                                        password show/hide
  assets/images/logo.jpeg              - Logo

HOW THE DATA MODEL WORKS
-----------------------------
js/data.js seeds an in-memory DB object (patients, users, pharmacy,
appointments, consultations, prescriptions — same shape as the original
MySQL schema) and persists every change to localStorage under the key
"ccms_db_v1". Every module page mutates it through helper functions
(addPatient, addUser, addDrug, addAppointment, addConsultation,
dispensePrescription, etc.) which all call saveDB() — so registering a
patient, booking an appointment, recording a consultation with a
prescription, and then dispensing it from Pharmacy are all connected:
a consultation's prescription shows up in Pending Prescriptions, and
dispensing it decrements the matching drug's stock in Inventory.

To wipe all data and start over from the seed values, clear this
browser's localStorage for the page's origin (or run
`localStorage.removeItem('ccms_db_v1')` in devtools and reload).

MULTI-PAGE NAVIGATION + AUTH
-----------------------------
Module pages live two folders deep (modules/<area>/<page>.html), so each
one sets `window.APP_ROOT = '../../';` before loading the shared scripts.
js/auth.js and js/nav.js use that to build correct relative links/redirects
(login, logout, sidebar links, the logo) regardless of how deep the page
is nested. Root-level pages don't set it and default to './'.

Route guards: requireLogin() gates any page behind a session; requireRole([...])
additionally redirects to 403.html if the logged-in role isn't allowed
(e.g. only Administrator can reach User Management).

WHAT CHANGED FROM THE PHP VERSION
-----------------------------------
- The MySQL database (database/schema.sql) and PHP backend (includes/,
  login.php, dashboard.php, logout.php, 403.php) were removed.
- All seed data (patients, staff accounts, pharmacy stock) now lives in
  js/data.js as plain JS objects instead of SQL INSERTs, and every write
  persists to localStorage instead of a real database.
- PHP sessions ($_SESSION) were replaced with the browser's
  sessionStorage, including the same 30-minute inactivity timeout.
- The sidebar/topbar (previously includes/header.php + footer.php) are
  now rendered client-side by js/nav.js based on the logged-in role.
- logout.php became a logout() JS function wired to the sidebar's
  logout button.
- Every module page referenced by the original nav (register, search,
  appointments, EHR, inventory, pending prescriptions, user management,
  reports) has been built out and wired to the shared data layer.

IMPORTANT SECURITY NOTE
-----------------------------
This is a client-side-only demo. There is no server validating
credentials or authorizing actions — anyone who views the page source
can read js/data.js and see the mock account passwords, and "login"
only controls what gets rendered in the browser, not real access
control. Do not use this as-is for a deployment holding real patient
data; a real backend (API + database + server-side auth) would be
needed for that.
