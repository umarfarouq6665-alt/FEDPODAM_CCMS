// ============================================================
// CCMS Mock Database | Federal Polytechnic Damaturu | 2025
// (Static front-end build — replaces database/schema.sql + PDO
// queries. Persisted to localStorage so changes survive page
// navigation and reloads, entirely in the browser.)
// ============================================================

const DB_KEY = 'ccms_db_v1';

const SEED_DB = {
    users: [
        { user_id: 1, full_name: 'Clinic Administrator', role: 'Administrator', staff_id: 'STF/FPD/ADM/001', email: 'admin@fpd.edu.ng', password: 'Admin@1234', phone: '08011112222', is_active: 1 },
        { user_id: 2, full_name: 'Dr. Abubakar Sani', role: 'Clinician', staff_id: 'STF/FPD/MED/001', email: 'doctor@fpd.edu.ng', password: 'Doctor@1234', phone: '08022223333', is_active: 1 },
        { user_id: 3, full_name: 'Fatima Musa', role: 'Pharmacist', staff_id: 'STF/FPD/PHA/001', email: 'pharmacy@fpd.edu.ng', password: 'Pharma@1234', phone: '08033334444', is_active: 1 },
        { user_id: 4, full_name: 'Halima Garba', role: 'Receptionist', staff_id: 'STF/FPD/REC/001', email: 'reception@fpd.edu.ng', password: 'Recept@1234', phone: '08044445555', is_active: 1 },
    ],

    patients: [
        { patient_id: 'FPD/P/0001', full_name: 'Abdullahi Ibrahim Musa', date_of_birth: '2003-04-15', gender: 'Male', category: 'Student', matric_staff_id: 'STU/FPD/23/1042', department: 'Computer Science', blood_group: 'O+', allergies: 'None', phone: '08012345678', email: 'abdullahi@fpd.edu.ng', address: 'FPD Campus', emergency_name: 'Ibrahim Musa', emergency_phone: '08023456789', reg_date: '2025-01-10 08:00:00' },
        { patient_id: 'FPD/P/0002', full_name: 'Fatima Garba Yusuf', date_of_birth: '2002-07-22', gender: 'Female', category: 'Student', matric_staff_id: 'STU/FPD/23/1087', department: 'Business Admin', blood_group: 'A+', allergies: 'Penicillin', phone: '08034567890', email: 'fatima@fpd.edu.ng', address: 'FPD Campus', emergency_name: 'Garba Yusuf', emergency_phone: '08045678901', reg_date: '2025-01-12 09:30:00' },
        { patient_id: 'FPD/P/0003', full_name: 'Dr. Aisha Bello', date_of_birth: '1985-03-10', gender: 'Female', category: 'Academic Staff', matric_staff_id: 'STF/FPD/LEC/042', department: 'Mathematics', blood_group: 'B+', allergies: 'None', phone: '08056789012', email: 'aisha.bello@fpd.edu.ng', address: 'Staff Quarters', emergency_name: 'Bello Mohammed', emergency_phone: '08067890123', reg_date: '2025-02-01 10:00:00' },
        { patient_id: 'FPD/P/0004', full_name: 'Suleiman Adamu Goni', date_of_birth: '2001-11-30', gender: 'Male', category: 'Student', matric_staff_id: 'STU/FPD/22/0956', department: 'Electrical Engineering', blood_group: 'AB+', allergies: 'Sulfa drugs', phone: '08078901234', email: 'suleiman@fpd.edu.ng', address: 'FPD Hostel Block A', emergency_name: 'Adamu Goni', emergency_phone: '08089012345', reg_date: '2025-02-14 11:00:00' },
        { patient_id: 'FPD/P/0005', full_name: 'Maryam Umar Kida', date_of_birth: '1990-06-18', gender: 'Female', category: 'Non-Academic Staff', matric_staff_id: 'STF/FPD/CLK/018', department: 'Registry', blood_group: 'O-', allergies: 'None', phone: '08090123456', email: 'maryam@fpd.edu.ng', address: 'Staff Quarters', emergency_name: 'Umar Kida', emergency_phone: '08001234567', reg_date: '2025-03-01 08:30:00' },
    ],

    // Left empty out of the box, same as the original schema.sql —
    // populated as staff use the Register / EHR / Appointments pages.
    appointments: [],
    consultations: [],
    prescriptions: [],

    pharmacy: [
        { drug_id: 1, drug_name: 'Artemether/Lumefantrine 80/480mg', category: 'Antimalarial', unit: 'Tablets', qty_in_stock: 200, reorder_level: 50, unit_cost: 350, expiry_date: '2026-12-31', supplier: 'Emzor Pharmaceuticals', updated_at: '2025-01-01 08:00:00' },
        { drug_id: 2, drug_name: 'Amoxicillin 500mg', category: 'Antibiotic', unit: 'Capsules', qty_in_stock: 350, reorder_level: 100, unit_cost: 60, expiry_date: '2026-06-30', supplier: 'May & Baker', updated_at: '2025-01-01 08:00:00' },
        { drug_id: 3, drug_name: 'Paracetamol 500mg', category: 'Analgesic', unit: 'Tablets', qty_in_stock: 500, reorder_level: 100, unit_cost: 15, expiry_date: '2027-01-31', supplier: 'Fidson Healthcare', updated_at: '2025-01-01 08:00:00' },
        { drug_id: 4, drug_name: 'Metronidazole 400mg', category: 'Antibiotic', unit: 'Tablets', qty_in_stock: 180, reorder_level: 50, unit_cost: 25, expiry_date: '2026-09-30', supplier: 'May & Baker', updated_at: '2025-01-01 08:00:00' },
        { drug_id: 5, drug_name: 'Omeprazole 20mg', category: 'Antacid', unit: 'Capsules', qty_in_stock: 120, reorder_level: 30, unit_cost: 45, expiry_date: '2026-08-31', supplier: 'Emzor Pharmaceuticals', updated_at: '2025-01-01 08:00:00' },
        { drug_id: 6, drug_name: 'Ciprofloxacin 500mg', category: 'Antibiotic', unit: 'Tablets', qty_in_stock: 90, reorder_level: 30, unit_cost: 55, expiry_date: '2026-10-31', supplier: 'Fidson Healthcare', updated_at: '2025-01-01 08:00:00' },
        { drug_id: 7, drug_name: 'Ibuprofen 400mg', category: 'Analgesic', unit: 'Tablets', qty_in_stock: 300, reorder_level: 80, unit_cost: 20, expiry_date: '2027-03-31', supplier: 'Emzor Pharmaceuticals', updated_at: '2025-01-01 08:00:00' },
        { drug_id: 8, drug_name: 'ORS Sachet', category: 'Rehydration', unit: 'Sachets', qty_in_stock: 40, reorder_level: 50, unit_cost: 10, expiry_date: '2026-05-30', supplier: 'May & Baker', updated_at: '2025-01-01 08:00:00' },
        { drug_id: 9, drug_name: 'Chlorphenamine 4mg', category: 'Antihistamine', unit: 'Tablets', qty_in_stock: 250, reorder_level: 60, unit_cost: 12, expiry_date: '2027-02-28', supplier: 'Fidson Healthcare', updated_at: '2025-01-01 08:00:00' },
        { drug_id: 10, drug_name: 'Cotrimoxazole 480mg', category: 'Antibiotic', unit: 'Tablets', qty_in_stock: 110, reorder_level: 40, unit_cost: 18, expiry_date: '2026-11-30', supplier: 'Emzor Pharmaceuticals', updated_at: '2025-01-01 08:00:00' },
    ],
};

function loadDB() {
    try {
        const raw = localStorage.getItem(DB_KEY);
        if (raw) return JSON.parse(raw);
    } catch (e) { /* fall through to seed */ }
    return JSON.parse(JSON.stringify(SEED_DB));
}

const DB = loadDB();

function saveDB() {
    localStorage.setItem(DB_KEY, JSON.stringify(DB));
}

function resetDB() {
    localStorage.removeItem(DB_KEY);
    window.location.reload();
}

function nowDateTimeStr_() {
    // local copy so data.js has no hard dependency on utils.js load order
    const d = new Date();
    const p = n => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}

function nextId(arr, key) {
    return arr.length ? Math.max(...arr.map(x => x[key])) + 1 : 1;
}

function nextPatientId() {
    const nums = DB.patients
        .map(p => parseInt(String(p.patient_id).split('/').pop(), 10))
        .filter(n => !isNaN(n));
    const next = (nums.length ? Math.max(...nums) : 0) + 1;
    return 'FPD/P/' + String(next).padStart(4, '0');
}

// ---- Patients ----
function findPatient(id) { return DB.patients.find(p => p.patient_id === id); }

function addPatient(data) {
    const patient = Object.assign({ patient_id: nextPatientId(), reg_date: nowDateTimeStr_() }, data);
    DB.patients.push(patient);
    saveDB();
    return patient;
}

// ---- Users (staff) ----
function findUser(id) { return DB.users.find(u => u.user_id === id); }

function addUser(data) {
    const user = Object.assign({ user_id: nextId(DB.users, 'user_id'), is_active: 1 }, data);
    DB.users.push(user);
    saveDB();
    return user;
}
function updateUser(id, patch) {
    const u = findUser(id);
    if (u) Object.assign(u, patch);
    saveDB();
    return u;
}
function deleteUser(id) {
    DB.users = DB.users.filter(u => u.user_id !== id);
    saveDB();
}

// ---- Pharmacy ----
function findDrug(id) { return DB.pharmacy.find(d => d.drug_id === id); }

function addDrug(data) {
    const drug = Object.assign({ drug_id: nextId(DB.pharmacy, 'drug_id'), updated_at: nowDateTimeStr_() }, data);
    DB.pharmacy.push(drug);
    saveDB();
    return drug;
}
function updateDrug(id, patch) {
    const d = findDrug(id);
    if (d) Object.assign(d, patch, { updated_at: nowDateTimeStr_() });
    saveDB();
    return d;
}
function deleteDrug(id) {
    DB.pharmacy = DB.pharmacy.filter(d => d.drug_id !== id);
    saveDB();
}

// ---- Appointments ----
function addAppointment(data) {
    const appt = Object.assign({ appt_id: nextId(DB.appointments, 'appt_id'), status: 'Scheduled' }, data);
    DB.appointments.push(appt);
    saveDB();
    return appt;
}
function updateAppointmentStatus(id, status) {
    const a = DB.appointments.find(x => x.appt_id === id);
    if (a) a.status = status;
    saveDB();
    return a;
}

// ---- Consultations + Prescriptions ----
function addConsultation(data, prescriptions) {
    const consult = Object.assign({ consult_id: nextId(DB.consultations, 'consult_id'), consult_date: nowDateTimeStr_() }, data);
    DB.consultations.push(consult);
    (prescriptions || []).forEach(rx => {
        DB.prescriptions.push(Object.assign(
            { rx_id: nextId(DB.prescriptions, 'rx_id'), consult_id: consult.consult_id, dispensed: 0, dispensed_by: null, dispensed_at: null },
            rx
        ));
    });
    saveDB();
    return consult;
}

function dispensePrescription(rxId, dispensedByUserId) {
    const rx = DB.prescriptions.find(r => r.rx_id === rxId);
    if (!rx || rx.dispensed) return null;
    rx.dispensed = 1;
    rx.dispensed_by = dispensedByUserId;
    rx.dispensed_at = nowDateTimeStr_();
    const drug = DB.pharmacy.find(d => d.drug_name === rx.drug_name);
    if (drug) drug.qty_in_stock = Math.max(0, drug.qty_in_stock - Number(rx.qty_prescribed || 0));
    saveDB();
    return rx;
}
