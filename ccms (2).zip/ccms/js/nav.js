// ============================================================
// CCMS Sidebar + Topbar Layout | 2025
// (Static front-end build — replaces includes/header.php +
// includes/footer.php. Renders the role-based nav client-side.
// Relies on escapeHtml/formatDateTime from js/utils.js and
// window.APP_ROOT from the page's inline bootstrap script.)
// ============================================================

const NAV_ITEMS = {
    Administrator: [
        { url: 'dashboard.html', icon: '📊', label: 'Dashboard' },
        { url: 'modules/admin/users.html', icon: '👥', label: 'User Management' },
        { url: 'modules/admin/reports.html', icon: '📊', label: 'Reports' },
        { url: 'modules/reception/search.html', icon: '🔍', label: 'Patient Search' },
        { url: 'modules/reception/register.html', icon: '📝', label: 'Register Patient' },
        { url: 'modules/reception/appointment.html', icon: '📅', label: 'Appointments' },
        { url: 'modules/clinician/patients.html', icon: '🩺', label: 'Patient EHR' },
        { url: 'modules/pharmacy/inventory.html', icon: '💊', label: 'Pharmacy Inventory' },
        { url: 'modules/pharmacy/pending.html', icon: '⏳', label: 'Pending Prescriptions' },
    ],
    Clinician: [
        { url: 'dashboard.html', icon: '📊', label: 'Dashboard' },
        { url: 'modules/clinician/patients.html', icon: '🩺', label: 'Patient EHR' },
        { url: 'modules/reception/search.html', icon: '🔍', label: 'Patient Search' },
        { url: 'modules/admin/reports.html', icon: '📊', label: 'Reports' },
    ],
    Pharmacist: [
        { url: 'dashboard.html', icon: '📊', label: 'Dashboard' },
        { url: 'modules/pharmacy/pending.html', icon: '💊', label: 'Pending Prescriptions' },
        { url: 'modules/pharmacy/inventory.html', icon: '📦', label: 'Inventory' },
        { url: 'modules/reception/search.html', icon: '🔍', label: 'Patient Search' },
    ],
    Receptionist: [
        { url: 'dashboard.html', icon: '📊', label: 'Dashboard' },
        { url: 'modules/reception/register.html', icon: '📝', label: 'Register Patient' },
        { url: 'modules/reception/search.html', icon: '🔍', label: 'Patient Search' },
        { url: 'modules/reception/appointment.html', icon: '📅', label: 'Appointments' },
    ],
};

function isActiveNavUrl(url) {
    const path = window.location.pathname.replace(/^\//, '');
    return path === url || path.endsWith('/' + url);
}

function renderLayout(pageTitle) {
    document.title = `${pageTitle} | ${SITE_NAME}`;

    const user = currentUser();
    const role = user.role;
    const color = roleColor(role);
    document.documentElement.style.setProperty('--role-color', color);

    const base = appRoot();
    const items = NAV_ITEMS[role] || [];

    const sidebar = document.getElementById('sidebar');
    if (sidebar) {
        sidebar.innerHTML = `
            <div class="sidebar-brand">
                <img src="${base}assets/images/logo.jpeg" alt="Federal Polytechnic Damaturu Logo" class="brand-mark">
                <div>
                    <span class="brand-title">Clinic Portal</span>
                    <span class="brand-sub">CCMS v1.0</span>
                </div>
            </div>

            <div class="role-badge">
                <span class="role-dot" style="background:${color}"></span>
                ${escapeHtml(role)}
            </div>

            <div class="sidebar-nav">
                ${items.map(item => `
                    <a href="${base}${item.url}" class="nav-item ${isActiveNavUrl(item.url) ? 'active' : ''}">
                        <span class="nav-icon">${item.icon}</span>
                        ${escapeHtml(item.label)}
                    </a>
                `).join('')}
            </div>

            <div class="sidebar-footer">
                <div class="user-info">
                    <div class="user-avatar" style="background:${color}">${escapeHtml((user.name || 'U').charAt(0).toUpperCase())}</div>
                    <div>
                        <div class="user-name">${escapeHtml(user.name || 'User')}</div>
                        <div class="user-role">${escapeHtml(role)}</div>
                    </div>
                </div>
                <a href="#" class="logout-btn" title="Logout" onclick="logout(); return false;">⏻</a>
            </div>
        `;
    }

    const topbar = document.getElementById('topbar');
    if (topbar) {
        topbar.innerHTML = `
            <button class="menu-toggle" onclick="toggleSidebar()" aria-label="Toggle menu">☰</button>
            <h1 class="page-title">${escapeHtml(pageTitle)}</h1>
            <div class="topbar-right">
                <span class="inst-name">${INST_NAME}</span>
                <span class="topbar-date" id="topbar-date"></span>
            </div>
        `;
        const dateEl = document.getElementById('topbar-date');
        if (dateEl) dateEl.textContent = formatDateTime(new Date());
    }
}
