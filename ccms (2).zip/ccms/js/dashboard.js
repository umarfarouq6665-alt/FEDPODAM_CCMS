// ============================================================
// dashboard.js - Role-aware CCMS Dashboard | FPD 2025
// (Static front-end build — replaces dashboard.php. Computes the
// same stats/queries client-side against js/data.js.)
// ============================================================

document.addEventListener('DOMContentLoaded', () => {
    requireLogin();
    if (!isLoggedIn()) return;

    const role = currentUser().role;

    renderLayout('Dashboard');
    renderStats(role);
    renderRecentGrid(role);
});

function roleModuleFolder(role) {
    if (role === 'Receptionist') return 'reception';
    if (role === 'Administrator') return 'admin';
    return 'clinician';
}

function computeStats() {
    const today = todayStr();
    return {
        patients: DB.patients.length,
        apptsToday: DB.appointments.filter(a => a.appt_date === today && a.status === 'Scheduled').length,
        consultsToday: DB.consultations.filter(c => c.consult_date.slice(0, 10) === today).length,
        pendingRx: DB.prescriptions.filter(p => !p.dispensed).length,
        lowStock: DB.pharmacy.filter(d => d.qty_in_stock <= d.reorder_level).length,
        usersActive: DB.users.filter(u => u.is_active).length,
    };
}

function renderStats(role) {
    const s = computeStats();
    let html = `
        <div class="stat-card">
            <div class="stat-icon">👥</div>
            <div class="stat-value">${s.patients.toLocaleString()}</div>
            <div class="stat-label">Registered Patients</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">📅</div>
            <div class="stat-value">${s.apptsToday}</div>
            <div class="stat-label">Appointments Today</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">🩺</div>
            <div class="stat-value">${s.consultsToday}</div>
            <div class="stat-label">Consultations Today</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon">💊</div>
            <div class="stat-value">${s.pendingRx}</div>
            <div class="stat-label">Pending Prescriptions</div>
            ${s.pendingRx > 0 ? '<div class="stat-trend">⚠ Awaiting dispensing</div>' : ''}
        </div>
    `;

    if (['Administrator', 'Pharmacist'].includes(role)) {
        html += `
        <div class="stat-card">
            <div class="stat-icon">📦</div>
            <div class="stat-value">${s.lowStock}</div>
            <div class="stat-label">Low Stock Alerts</div>
            ${s.lowStock > 0 ? '<div class="stat-trend" style="color:#c81e1e;">⚠ Needs restocking</div>' : ''}
        </div>`;
    }

    if (role === 'Administrator') {
        html += `
        <div class="stat-card">
            <div class="stat-icon">⚙️</div>
            <div class="stat-value">${s.usersActive}</div>
            <div class="stat-label">Active Staff Accounts</div>
        </div>`;
    }

    document.getElementById('stat-grid').innerHTML = html;

    const banner = document.getElementById('low-stock-banner');
    if (s.lowStock > 0 && ['Administrator', 'Pharmacist', 'Clinician'].includes(role)) {
        banner.innerHTML = `⚠️ <strong>${s.lowStock} drug(s)</strong> in the pharmacy are at or below reorder level.
            <a href="modules/pharmacy/inventory.html" style="color:inherit;font-weight:700;margin-left:6px;">View Inventory →</a>`;
        banner.style.display = '';
    } else {
        banner.style.display = 'none';
    }
}

function buildPatientsCard(role) {
    const recent = [...DB.patients]
        .sort((a, b) => new Date(b.reg_date) - new Date(a.reg_date))
        .slice(0, 6);

    const rows = recent.length
        ? recent.map(p => `
            <tr>
                <td><span class="pid-code">${escapeHtml(p.patient_id)}</span></td>
                <td>${escapeHtml(p.full_name)}</td>
                <td><span class="badge badge-info">${escapeHtml(p.category)}</span></td>
                <td style="font-size:12px;color:#6b7280;">${formatDate(p.reg_date)}</td>
            </tr>`).join('')
        : `<tr><td colspan="4"><div class="empty-state"><div class="empty-state-icon">👤</div><h3>No patients registered yet</h3></div></td></tr>`;

    return `
        <div class="card">
            <div class="card-header">
                <span class="card-title">👥 Recent Patients</span>
                <a href="modules/reception/search.html" class="btn btn-ghost btn-sm">View All</a>
            </div>
            <div class="table-wrap">
                <table>
                    <thead><tr><th>PID</th><th>Name</th><th>Category</th><th>Registered</th></tr></thead>
                    <tbody>${rows}</tbody>
                </table>
            </div>
        </div>`;
}

function buildAppointmentsCard(role) {
    const today = todayStr();
    const upcoming = DB.appointments
        .filter(a => a.appt_date >= today && a.status === 'Scheduled')
        .sort((a, b) => (a.appt_date + a.appt_time).localeCompare(b.appt_date + b.appt_time))
        .slice(0, 6);

    const rows = upcoming.length
        ? upcoming.map(a => {
            const patient = findPatient(a.patient_id);
            const clinician = findUser(a.clinician_id);
            return `
            <tr>
                <td>${escapeHtml(patient ? patient.full_name : a.patient_id)}</td>
                <td>${escapeHtml(clinician ? clinician.full_name : '—')}</td>
                <td>${formatDate(a.appt_date)}</td>
                <td>${formatTime(a.appt_time)}</td>
                <td>${escapeHtml(a.reason || '—')}</td>
            </tr>`;
        }).join('')
        : `<tr><td colspan="5"><div class="empty-state"><div class="empty-state-icon">📅</div><h3>No upcoming appointments</h3></div></td></tr>`;

    return `
        <div class="card">
            <div class="card-header">
                <span class="card-title">📅 Upcoming Appointments</span>
                <a href="modules/reception/appointment.html" class="btn btn-ghost btn-sm">View All</a>
            </div>
            <div class="table-wrap">
                <table>
                    <thead><tr><th>Patient</th><th>Clinician</th><th>Date</th><th>Time</th><th>Reason</th></tr></thead>
                    <tbody>${rows}</tbody>
                </table>
            </div>
        </div>`;
}

function buildConsultationsCard() {
    const recent = [...DB.consultations]
        .sort((a, b) => new Date(b.consult_date) - new Date(a.consult_date))
        .slice(0, 6);

    const rows = recent.length
        ? recent.map(c => {
            const patient = findPatient(c.patient_id);
            const clinician = findUser(c.clinician_id);
            return `
            <tr>
                <td>${escapeHtml(patient ? patient.full_name : c.patient_id)}</td>
                <td>${escapeHtml(c.diagnosis)}</td>
                <td>${escapeHtml(clinician ? clinician.full_name : '—')}</td>
                <td style="font-size:12px;color:#6b7280;">${formatDate(c.consult_date)}</td>
            </tr>`;
        }).join('')
        : `<tr><td colspan="4"><div class="empty-state"><div class="empty-state-icon">🩺</div><h3>No consultations recorded yet</h3></div></td></tr>`;

    return `
        <div class="card">
            <div class="card-header">
                <span class="card-title">🩺 Recent Consultations</span>
            </div>
            <div class="table-wrap">
                <table>
                    <thead><tr><th>Patient</th><th>Diagnosis</th><th>Clinician</th><th>Date</th></tr></thead>
                    <tbody>${rows}</tbody>
                </table>
            </div>
        </div>`;
}

function buildLowStockCard() {
    const low = DB.pharmacy
        .filter(d => d.qty_in_stock <= d.reorder_level)
        .sort((a, b) => a.qty_in_stock - b.qty_in_stock)
        .slice(0, 5);

    const rows = low.length
        ? low.map(d => `
            <tr>
                <td>${escapeHtml(d.drug_name)}</td>
                <td style="color:#c81e1e;font-weight:700;">${d.qty_in_stock}</td>
                <td>${d.reorder_level}</td>
                <td>${escapeHtml(d.unit)}</td>
            </tr>`).join('')
        : `<tr><td colspan="4"><div class="empty-state"><div class="empty-state-icon">📦</div><h3>All stock levels are healthy</h3></div></td></tr>`;

    return `
        <div class="card">
            <div class="card-header">
                <span class="card-title">📦 Low Stock Drugs</span>
                <a href="modules/pharmacy/inventory.html" class="btn btn-ghost btn-sm">View Inventory</a>
            </div>
            <div class="table-wrap">
                <table>
                    <thead><tr><th>Drug</th><th>In Stock</th><th>Reorder Level</th><th>Unit</th></tr></thead>
                    <tbody>${rows}</tbody>
                </table>
            </div>
        </div>`;
}

function renderRecentGrid(role) {
    let html = buildPatientsCard(role) + buildAppointmentsCard(role) + buildConsultationsCard();
    if (['Administrator', 'Pharmacist'].includes(role)) {
        html += buildLowStockCard();
    }
    document.getElementById('recent-grid').innerHTML = html;
}
