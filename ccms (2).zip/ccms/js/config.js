// ============================================================
// CCMS Configuration | Federal Polytechnic Damaturu | 2025
// (Static front-end build — replaces includes/config.php)
// ============================================================

const SITE_NAME = 'CCMS - FPD Clinic';
const INST_NAME = 'Federal Polytechnic Damaturu';
const SESSION_TIMEOUT = 1800; // seconds (30 minutes)

function roleColor(role) {
    switch (role) {
        case 'Administrator': return '#1a56db';
        case 'Clinician': return '#057a55';
        case 'Pharmacist': return '#9061f9';
        case 'Receptionist': return '#e3a008';
        default: return '#6b7280';
    }
}
