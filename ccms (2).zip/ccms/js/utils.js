// ============================================================
// CCMS Shared Utilities | 2025
// ============================================================

function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str == null ? '' : String(str);
    return div.innerHTML;
}

function pad2(n) {
    return String(n).padStart(2, '0');
}

function todayStr() {
    const d = new Date();
    return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}

function nowDateTimeStr() {
    const d = new Date();
    return `${todayStr()} ${pad2(d.getHours())}:${pad2(d.getMinutes())}:${pad2(d.getSeconds())}`;
}

function formatDate(dateStr) {
    if (!dateStr) return '—';
    const d = new Date(String(dateStr).replace(' ', 'T'));
    if (isNaN(d)) return dateStr;
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return `${pad2(d.getDate())} ${months[d.getMonth()]} ${d.getFullYear()}`;
}

function formatDateTime(d) {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return `${pad2(d.getDate())} ${months[d.getMonth()]} ${d.getFullYear()}, ${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
}

function formatTime(timeStr) {
    if (!timeStr) return '—';
    const [h, m] = timeStr.split(':').map(Number);
    const period = h >= 12 ? 'PM' : 'AM';
    const h12 = ((h + 11) % 12) + 1;
    return `${pad2(h12)}:${pad2(m)} ${period}`;
}

function calcAge(dobStr) {
    if (!dobStr) return '—';
    const dob = new Date(dobStr);
    if (isNaN(dob)) return '—';
    const now = new Date();
    let age = now.getFullYear() - dob.getFullYear();
    const m = now.getMonth() - dob.getMonth();
    if (m < 0 || (m === 0 && now.getDate() < dob.getDate())) age--;
    return age;
}

function showToast(message) {
    const existing = document.getElementById('ccms-toast');
    if (existing) existing.remove();
    const toast = document.createElement('div');
    toast.id = 'ccms-toast';
    toast.className = 'toast';
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 2600);
}
