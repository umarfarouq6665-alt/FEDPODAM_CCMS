// ============================================================
// CCMS Modal Helper | 2025
// ============================================================

function openModal(innerHtml, opts) {
    let root = document.getElementById('modal-root');
    if (!root) {
        root = document.createElement('div');
        root.id = 'modal-root';
        document.body.appendChild(root);
    }
    const cls = 'modal' + (opts && opts.className ? ' ' + opts.className : '');
    root.innerHTML = `
        <div class="modal-backdrop" id="modal-backdrop">
            <div class="${cls}" role="dialog" aria-modal="true">${innerHtml}</div>
        </div>`;
    document.getElementById('modal-backdrop').addEventListener('click', (e) => {
        if (e.target.id === 'modal-backdrop') closeModal();
    });
    document.body.style.overflow = 'hidden';
}

function closeModal() {
    const root = document.getElementById('modal-root');
    if (root) root.innerHTML = '';
    document.body.style.overflow = '';
}

document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeModal();
});
