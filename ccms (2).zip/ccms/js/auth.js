// ============================================================
// CCMS Auth & Session Guard | 2025
// (Static front-end build — replaces includes/auth.php.
// Session lives in sessionStorage instead of PHP $_SESSION, so
// it clears automatically when the browser tab closes.
//
// NOTE: this is a purely client-side demo. Credentials in
// js/data.js are visible to anyone who opens the source, and
// "login" only gates which HTML gets rendered in the browser —
// it is not a real security boundary. Do not use as-is for a
// deployment holding real patient data.
//
// Pages nested under modules/<area>/ must set
// `window.APP_ROOT = '../../';` in an inline <script> BEFORE
// this file loads, so redirects resolve back to the site root. )
// ============================================================

const SESSION_KEY = 'ccms_session';

function appRoot() {
    return window.APP_ROOT || './';
}

function redirectTo(page) {
    window.location.href = appRoot() + page;
}

function getSession() {
    const raw = sessionStorage.getItem(SESSION_KEY);
    return raw ? JSON.parse(raw) : null;
}

function setSession(session) {
    sessionStorage.setItem(SESSION_KEY, JSON.stringify(session));
}

function isLoggedIn() {
    const session = getSession();
    return !!(session && session.user_id && session.role);
}

function requireLogin() {
    const session = getSession();
    if (!session) {
        redirectTo('login.html');
        return;
    }

    const now = Math.floor(Date.now() / 1000);
    if (session.last_activity && (now - session.last_activity) > SESSION_TIMEOUT) {
        sessionStorage.removeItem(SESSION_KEY);
        redirectTo('login.html?timeout=1');
        return;
    }

    session.last_activity = now;
    setSession(session);
}

function requireRole(allowed) {
    requireLogin();
    const session = getSession();
    if (session && !allowed.includes(session.role)) {
        redirectTo('403.html');
    }
}

function currentUser() {
    const session = getSession();
    return {
        id: session ? session.user_id : null,
        name: session ? session.full_name : '',
        role: session ? session.role : '',
    };
}

function attemptLogin(email, password) {
    if (!email || !password) {
        return { ok: false, error: 'Please enter both your email address and password.' };
    }

    const user = DB.users.find(u => u.email === email);
    if (!user || user.password !== password) {
        return { ok: false, error: 'Invalid credentials. Please check your email and password.' };
    }
    if (!user.is_active) {
        return { ok: false, error: 'Your account has been deactivated. Please contact the Administrator.' };
    }

    setSession({
        user_id: user.user_id,
        full_name: user.full_name,
        role: user.role,
        last_activity: Math.floor(Date.now() / 1000),
    });
    return { ok: true };
}

function logout() {
    sessionStorage.removeItem(SESSION_KEY);
    redirectTo('login.html');
}
