// ============================================================
// Patient Search | modules/reception/search.html
// ============================================================

document.addEventListener('DOMContentLoaded', () => {
    requireLogin();
    if (!isLoggedIn()) return;
    renderLayout('Patient Search');

    const input = document.getElementById('search-input');
    input.addEventListener('input', () => renderResults(input.value.trim().toLowerCase()));
    renderResults('');
});

function renderResults(query) {
    const tbody = document.getElementById('results-body');
    let list = [...DB.patients].sort((a, b) => new Date(b.reg_date) - new Date(a.reg_date));

    if (query) {
        list = list.filter(p =>
            p.full_name.toLowerCase().includes(query) ||
            p.patient_id.toLowerCase().includes(query) ||
            (p.matric_staff_id || '').toLowerCase().includes(query) ||
            (p.phone || '').toLowerCase().includes(query)
        );
    }

    if (!list.length) {
        tbody.innerHTML = `<tr><td colspan="7"><div class="empty-state"><div class="empty-state-icon">🔍</div><h3>No matching patients</h3></div></td></tr>`;
        return;
    }

    tbody.innerHTML = list.map(p => `
        <tr>
            <td><span class="pid-code">${escapeHtml(p.patient_id)}</span></td>
            <td>${escapeHtml(p.full_name)}</td>
            <td><span class="badge badge-info">${escapeHtml(p.category)}</span></td>
            <td>${escapeHtml(p.gender)}</td>
            <td>${escapeHtml(p.phone || '—')}</td>
            <td style="font-size:12px;color:var(--ink-600);">${formatDate(p.reg_date)}</td>
            <td><button class="btn btn-ghost btn-sm" onclick="viewPatient('${p.patient_id}')">View</button></td>
        </tr>`).join('');
}

function viewPatient(id) {
    const p = findPatient(id);
    if (!p) return;

    const history = DB.consultations
        .filter(c => c.patient_id === id)
        .sort((a, b) => new Date(b.consult_date) - new Date(a.consult_date));

    openModal(`
        <div class="modal-header">
            <span class="modal-title">${escapeHtml(p.full_name)}</span>
            <button class="modal-close" onclick="closeModal()">✕</button>
        </div>
        <div class="modal-body">
            <div class="detail-grid">
                <div><div class="detail-label">Patient ID</div><div class="detail-value">${escapeHtml(p.patient_id)}</div></div>
                <div><div class="detail-label">Category</div><div class="detail-value">${escapeHtml(p.category)}</div></div>
                <div><div class="detail-label">Matric/Staff ID</div><div class="detail-value">${escapeHtml(p.matric_staff_id)}</div></div>
                <div><div class="detail-label">Department</div><div class="detail-value">${escapeHtml(p.department || '—')}</div></div>
                <div><div class="detail-label">Date of Birth</div><div class="detail-value">${formatDate(p.date_of_birth)} (${calcAge(p.date_of_birth)} yrs)</div></div>
                <div><div class="detail-label">Gender</div><div class="detail-value">${escapeHtml(p.gender)}</div></div>
                <div><div class="detail-label">Blood Group</div><div class="detail-value">${escapeHtml(p.blood_group || '—')}</div></div>
                <div><div class="detail-label">Phone</div><div class="detail-value">${escapeHtml(p.phone || '—')}</div></div>
                <div><div class="detail-label">Email</div><div class="detail-value">${escapeHtml(p.email || '—')}</div></div>
                <div><div class="detail-label">Registered</div><div class="detail-value">${formatDate(p.reg_date)}</div></div>
                <div class="full"><div class="detail-label">Allergies</div><div class="detail-value">${escapeHtml(p.allergies || 'None')}</div></div>
                <div class="full"><div class="detail-label">Address</div><div class="detail-value">${escapeHtml(p.address || '—')}</div></div>
                <div><div class="detail-label">Emergency Contact</div><div class="detail-value">${escapeHtml(p.emergency_name || '—')}</div></div>
                <div><div class="detail-label">Emergency Phone</div><div class="detail-value">${escapeHtml(p.emergency_phone || '—')}</div></div>
            </div>
            <div style="margin-top:22px;">
                <div class="detail-label" style="margin-bottom:10px;">Consultation History</div>
                ${history.length ? history.map(c => {
                    const clinician = findUser(c.clinician_id);
                    return `<div style="padding:10px 0;border-bottom:1px solid var(--border-soft);">
                        <div style="font-weight:700;font-size:13px;color:var(--navy-900);">${escapeHtml(c.diagnosis)}</div>
                        <div style="font-size:12px;color:var(--ink-600);margin-top:2px;">${escapeHtml(c.complaint)}</div>
                        <div style="font-size:11px;color:var(--ink-400);margin-top:4px;">${formatDate(c.consult_date)} · ${escapeHtml(clinician ? clinician.full_name : '—')}</div>
                    </div>`;
                }).join('') : '<div class="empty-state"><div class="empty-state-icon">🩺</div><h3>No consultations on record</h3></div>'}
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-ghost" onclick="closeModal()">Close</button>
        </div>
    `);
}
