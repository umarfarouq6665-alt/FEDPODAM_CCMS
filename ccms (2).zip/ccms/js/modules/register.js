// ============================================================
// Register Patient | modules/reception/register.html
// ============================================================

document.addEventListener('DOMContentLoaded', () => {
    requireRole(['Administrator', 'Receptionist']);
    if (!isLoggedIn()) return;
    renderLayout('Register Patient');

    document.getElementById('register-form').addEventListener('submit', (e) => {
        e.preventDefault();
        const alertBox = document.getElementById('form-alert');
        alertBox.innerHTML = '';

        const matric = document.getElementById('matric_staff_id').value.trim();
        if (DB.patients.some(p => p.matric_staff_id.toLowerCase() === matric.toLowerCase())) {
            alertBox.innerHTML = `<div class="alert alert-danger">🚫 A patient with matric/staff ID "${escapeHtml(matric)}" is already registered.</div>`;
            return;
        }

        const patient = addPatient({
            full_name: document.getElementById('full_name').value.trim(),
            date_of_birth: document.getElementById('date_of_birth').value,
            gender: document.getElementById('gender').value,
            category: document.getElementById('category').value,
            matric_staff_id: matric,
            department: document.getElementById('department').value.trim(),
            blood_group: document.getElementById('blood_group').value.trim(),
            allergies: document.getElementById('allergies').value.trim() || 'None',
            phone: document.getElementById('phone').value.trim(),
            email: document.getElementById('email').value.trim(),
            address: document.getElementById('address').value.trim(),
            emergency_name: document.getElementById('emergency_name').value.trim(),
            emergency_phone: document.getElementById('emergency_phone').value.trim(),
        });

        alertBox.innerHTML = `<div class="alert alert-success">✅ Patient registered successfully. Assigned Patient ID: <strong>${escapeHtml(patient.patient_id)}</strong></div>`;
        document.getElementById('register-form').reset();
        showToast(`Patient ${patient.patient_id} registered`);
    });
});
