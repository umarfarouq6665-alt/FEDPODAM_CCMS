// ============================================================
// Reports | modules/admin/reports.html
// ============================================================

document.addEventListener('DOMContentLoaded', () => {
    requireRole(['Administrator', 'Clinician']);
    if (!isLoggedIn()) return;
    renderLayout('Reports');
    renderReports();
});

function renderBars(containerId, data) {
    const el = document.getElementById(containerId);
    if (!data.length) {
        el.innerHTML = '<div class="empty-state"><div class="empty-state-icon">📊</div><h3>No data yet</h3></div>';
        return;
    }
    const max = Math.max(1, ...data.map(d => d.value));
    el.innerHTML = data
        .sort((a, b) => b.value - a.value)
        .map(d => `
            <div class="bar-row">
                <span class="bar-label" title="${escapeHtml(d.label)}">${escapeHtml(d.label)}</span>
                <div class="bar-track"><div class="bar-fill" style="width:${(d.value / max * 100).toFixed(0)}%;"></div></div>
                <span class="bar-value">${d.value}</span>
            </div>`).join('');
}

function renderReports() {
    const totalPatients = DB.patients.length;
    const totalConsults = DB.consultations.length;
    const totalAppts = DB.appointments.length;
    const dispensedRx = DB.prescriptions.filter(r => r.dispensed).length;

    document.getElementById('report-stats').innerHTML = `
        <div class="stat-card"><div class="stat-icon">👥</div><div class="stat-value">${totalPatients}</div><div class="stat-label">Total Patients</div></div>
        <div class="stat-card"><div class="stat-icon">🩺</div><div class="stat-value">${totalConsults}</div><div class="stat-label">Total Consultations</div></div>
        <div class="stat-card"><div class="stat-icon">📅</div><div class="stat-value">${totalAppts}</div><div class="stat-label">Total Appointments</div></div>
        <div class="stat-card"><div class="stat-icon">💊</div><div class="stat-value">${dispensedRx}</div><div class="stat-label">Prescriptions Dispensed</div></div>
    `;

    const byCategory = {};
    DB.patients.forEach(p => { byCategory[p.category] = (byCategory[p.category] || 0) + 1; });
    renderBars('bars-category', Object.entries(byCategory).map(([label, value]) => ({ label, value })));

    const byClinician = {};
    DB.consultations.forEach(c => {
        const u = findUser(c.clinician_id);
        const name = u ? u.full_name : `User #${c.clinician_id}`;
        byClinician[name] = (byClinician[name] || 0) + 1;
    });
    renderBars('bars-clinician', Object.entries(byClinician).map(([label, value]) => ({ label, value })));

    const byStatus = {};
    DB.appointments.forEach(a => { byStatus[a.status] = (byStatus[a.status] || 0) + 1; });
    renderBars('bars-appt-status', Object.entries(byStatus).map(([label, value]) => ({ label, value })));

    const low = DB.pharmacy.filter(d => d.qty_in_stock <= d.reorder_level).sort((a, b) => a.qty_in_stock - b.qty_in_stock);
    document.getElementById('report-lowstock').innerHTML = low.length
        ? low.map(d => `<tr><td>${escapeHtml(d.drug_name)}</td><td style="color:var(--danger);font-weight:700;">${d.qty_in_stock}</td><td>${d.reorder_level}</td></tr>`).join('')
        : `<tr><td colspan="3"><div class="empty-state"><div class="empty-state-icon">📦</div><h3>All stock levels are healthy</h3></div></td></tr>`;
}
