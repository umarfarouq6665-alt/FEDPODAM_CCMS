// ============================================================
// Pharmacy Inventory | modules/pharmacy/inventory.html
// ============================================================

document.addEventListener('DOMContentLoaded', () => {
    requireRole(['Administrator', 'Pharmacist']);
    if (!isLoggedIn()) return;
    renderLayout('Pharmacy Inventory');
    renderDrugs();

    document.getElementById('search-input').addEventListener('input', renderDrugs);
});

function renderDrugs() {
    const query = document.getElementById('search-input').value.trim().toLowerCase();
    let list = [...DB.pharmacy].sort((a, b) => a.drug_name.localeCompare(b.drug_name));
    if (query) {
        list = list.filter(d =>
            d.drug_name.toLowerCase().includes(query) ||
            (d.category || '').toLowerCase().includes(query)
        );
    }

    const tbody = document.getElementById('drug-body');
    if (!list.length) {
        tbody.innerHTML = `<tr><td colspan="8"><div class="empty-state"><div class="empty-state-icon">💊</div><h3>No drugs found</h3></div></td></tr>`;
        return;
    }

    tbody.innerHTML = list.map(d => {
        const low = d.qty_in_stock <= d.reorder_level;
        return `
        <tr>
            <td>${escapeHtml(d.drug_name)}</td>
            <td><span class="badge badge-muted">${escapeHtml(d.category)}</span></td>
            <td style="${low ? 'color:var(--danger);font-weight:700;' : ''}">${d.qty_in_stock}${low ? ' ⚠' : ''}</td>
            <td>${d.reorder_level}</td>
            <td>${escapeHtml(d.unit)}</td>
            <td>₦${Number(d.unit_cost || 0).toLocaleString()}</td>
            <td style="font-size:12px;color:var(--ink-600);">${formatDate(d.expiry_date)}</td>
            <td>
                <div class="row-actions">
                    <button class="icon-btn" title="Restock" onclick="quickRestock(${d.drug_id})">＋</button>
                    <button class="icon-btn" title="Edit" onclick="openDrugModal(${d.drug_id})">✎</button>
                    <button class="icon-btn danger" title="Delete" onclick="removeDrug(${d.drug_id})">🗑</button>
                </div>
            </td>
        </tr>`;
    }).join('');
}

function quickRestock(id) {
    const drug = findDrug(id);
    if (!drug) return;
    const amount = prompt(`Add how many units to "${drug.drug_name}"? (Currently ${drug.qty_in_stock} ${drug.unit})`, '50');
    if (amount === null) return;
    const n = parseInt(amount, 10);
    if (isNaN(n) || n <= 0) { showToast('Enter a valid positive number'); return; }
    updateDrug(id, { qty_in_stock: drug.qty_in_stock + n });
    renderDrugs();
    showToast(`Restocked ${n} ${drug.unit} of ${drug.drug_name}`);
}

function removeDrug(id) {
    const drug = findDrug(id);
    if (!drug) return;
    if (!confirm(`Remove "${drug.drug_name}" from inventory?`)) return;
    deleteDrug(id);
    renderDrugs();
    showToast('Drug removed');
}

function openDrugModal(id) {
    const drug = id ? findDrug(id) : null;

    openModal(`
        <div class="modal-header">
            <span class="modal-title">${drug ? 'Edit Drug' : 'Add Drug'}</span>
            <button class="modal-close" onclick="closeModal()">✕</button>
        </div>
        <form id="drug-form">
            <div class="modal-body">
                <div id="drug-alert"></div>
                <div class="form-grid">
                    <div class="form-group full"><label for="d-name">Drug Name *</label><input type="text" id="d-name" required value="${drug ? escapeHtml(drug.drug_name) : ''}"></div>
                    <div class="form-group"><label for="d-category">Category</label><input type="text" id="d-category" value="${drug ? escapeHtml(drug.category) : 'General'}"></div>
                    <div class="form-group"><label for="d-unit">Unit</label><input type="text" id="d-unit" value="${drug ? escapeHtml(drug.unit) : 'Tablets'}"></div>
                    <div class="form-group"><label for="d-qty">Quantity in Stock *</label><input type="number" min="0" id="d-qty" required value="${drug ? drug.qty_in_stock : 0}"></div>
                    <div class="form-group"><label for="d-reorder">Reorder Level *</label><input type="number" min="0" id="d-reorder" required value="${drug ? drug.reorder_level : 50}"></div>
                    <div class="form-group"><label for="d-cost">Unit Cost (₦)</label><input type="number" min="0" step="0.01" id="d-cost" value="${drug ? drug.unit_cost : 0}"></div>
                    <div class="form-group"><label for="d-expiry">Expiry Date</label><input type="date" id="d-expiry" value="${drug ? drug.expiry_date : ''}"></div>
                    <div class="form-group full"><label for="d-supplier">Supplier</label><input type="text" id="d-supplier" value="${drug ? escapeHtml(drug.supplier || '') : ''}"></div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-ghost" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-navy">${drug ? 'Save Changes' : 'Add Drug'}</button>
            </div>
        </form>
    `);

    document.getElementById('drug-form').addEventListener('submit', (e) => {
        e.preventDefault();
        const name = document.getElementById('d-name').value.trim();
        const data = {
            drug_name: name,
            category: document.getElementById('d-category').value.trim() || 'General',
            unit: document.getElementById('d-unit').value.trim() || 'Tablets',
            qty_in_stock: parseInt(document.getElementById('d-qty').value, 10) || 0,
            reorder_level: parseInt(document.getElementById('d-reorder').value, 10) || 0,
            unit_cost: parseFloat(document.getElementById('d-cost').value) || 0,
            expiry_date: document.getElementById('d-expiry').value,
            supplier: document.getElementById('d-supplier').value.trim(),
        };

        const dupe = DB.pharmacy.find(x => x.drug_name.toLowerCase() === name.toLowerCase() && (!drug || x.drug_id !== drug.drug_id));
        if (dupe) {
            document.getElementById('drug-alert').innerHTML = `<div class="alert alert-danger">🚫 A drug named "${escapeHtml(name)}" already exists.</div>`;
            return;
        }

        if (drug) {
            updateDrug(drug.drug_id, data);
            showToast('Drug updated');
        } else {
            addDrug(data);
            showToast('Drug added to inventory');
        }
        closeModal();
        renderDrugs();
    });
}
