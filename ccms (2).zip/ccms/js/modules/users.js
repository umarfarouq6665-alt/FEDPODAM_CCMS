// ============================================================
// User Management | modules/admin/users.html
// ============================================================

document.addEventListener('DOMContentLoaded', () => {
    requireRole(['Administrator']);
    if (!isLoggedIn()) return;
    renderLayout('User Management');
    renderUsers();
    document.getElementById('search-input').addEventListener('input', renderUsers);
});

function renderUsers() {
    const query = document.getElementById('search-input').value.trim().toLowerCase();
    let list = [...DB.users].sort((a, b) => a.full_name.localeCompare(b.full_name));
    if (query) {
        list = list.filter(u =>
            u.full_name.toLowerCase().includes(query) ||
            u.email.toLowerCase().includes(query) ||
            u.role.toLowerCase().includes(query)
        );
    }

    const tbody = document.getElementById('user-body');
    if (!list.length) {
        tbody.innerHTML = `<tr><td colspan="6"><div class="empty-state"><div class="empty-state-icon">👥</div><h3>No staff found</h3></div></td></tr>`;
        return;
    }

    const me = currentUser();

    tbody.innerHTML = list.map(u => `
        <tr>
            <td>${escapeHtml(u.full_name)}</td>
            <td><span class="badge" style="color:${roleColor(u.role)};background:${roleColor(u.role)}1a;">${escapeHtml(u.role)}</span></td>
            <td style="font-family:var(--font-mono);font-size:12px;">${escapeHtml(u.staff_id)}</td>
            <td>${escapeHtml(u.email)}</td>
            <td><span class="badge ${u.is_active ? 'badge-success' : 'badge-muted'}">${u.is_active ? 'Active' : 'Inactive'}</span></td>
            <td>
                <div class="row-actions">
                    <button class="icon-btn" title="Edit" onclick="openUserModal(${u.user_id})">✎</button>
                    <button class="icon-btn" title="${u.is_active ? 'Deactivate' : 'Activate'}" onclick="toggleActive(${u.user_id})">${u.is_active ? '⏸' : '▶'}</button>
                    ${u.user_id !== me.id ? `<button class="icon-btn danger" title="Delete" onclick="removeUser(${u.user_id})">🗑</button>` : ''}
                </div>
            </td>
        </tr>`).join('');
}

function toggleActive(id) {
    const u = findUser(id);
    if (!u) return;
    updateUser(id, { is_active: u.is_active ? 0 : 1 });
    renderUsers();
    showToast(`${u.full_name} ${u.is_active ? 'deactivated' : 'activated'}`);
}

function removeUser(id) {
    const u = findUser(id);
    if (!u) return;
    if (!confirm(`Remove staff account "${u.full_name}"?`)) return;
    deleteUser(id);
    renderUsers();
    showToast('Staff account removed');
}

function openUserModal(id) {
    const user = id ? findUser(id) : null;

    openModal(`
        <div class="modal-header">
            <span class="modal-title">${user ? 'Edit Staff' : 'Add Staff'}</span>
            <button class="modal-close" onclick="closeModal()">✕</button>
        </div>
        <form id="user-form">
            <div class="modal-body">
                <div id="user-alert"></div>
                <div class="form-grid">
                    <div class="form-group full"><label for="u-name">Full Name *</label><input type="text" id="u-name" required value="${user ? escapeHtml(user.full_name) : ''}"></div>
                    <div class="form-group">
                        <label for="u-role">Role *</label>
                        <select id="u-role" required>
                            ${['Administrator', 'Clinician', 'Pharmacist', 'Receptionist'].map(r => `<option value="${r}" ${user && user.role === r ? 'selected' : ''}>${r}</option>`).join('')}
                        </select>
                    </div>
                    <div class="form-group"><label for="u-staffid">Staff ID *</label><input type="text" id="u-staffid" required value="${user ? escapeHtml(user.staff_id) : ''}"></div>
                    <div class="form-group"><label for="u-email">Email *</label><input type="email" id="u-email" required value="${user ? escapeHtml(user.email) : ''}"></div>
                    <div class="form-group"><label for="u-phone">Phone</label><input type="text" id="u-phone" value="${user ? escapeHtml(user.phone || '') : ''}"></div>
                    <div class="form-group full">
                        <label for="u-password">${user ? 'Reset Password' : 'Password *'}</label>
                        <input type="text" id="u-password" placeholder="${user ? 'Leave blank to keep current password' : ''}" ${user ? '' : 'required'}>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-ghost" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-navy">${user ? 'Save Changes' : 'Create Account'}</button>
            </div>
        </form>
    `);

    document.getElementById('user-form').addEventListener('submit', (e) => {
        e.preventDefault();
        const email = document.getElementById('u-email').value.trim();
        const staffId = document.getElementById('u-staffid').value.trim();
        const password = document.getElementById('u-password').value;

        const dupeEmail = DB.users.find(x => x.email.toLowerCase() === email.toLowerCase() && (!user || x.user_id !== user.user_id));
        if (dupeEmail) {
            document.getElementById('user-alert').innerHTML = `<div class="alert alert-danger">🚫 Email "${escapeHtml(email)}" is already in use.</div>`;
            return;
        }
        const dupeStaffId = DB.users.find(x => x.staff_id.toLowerCase() === staffId.toLowerCase() && (!user || x.user_id !== user.user_id));
        if (dupeStaffId) {
            document.getElementById('user-alert').innerHTML = `<div class="alert alert-danger">🚫 Staff ID "${escapeHtml(staffId)}" is already in use.</div>`;
            return;
        }

        const data = {
            full_name: document.getElementById('u-name').value.trim(),
            role: document.getElementById('u-role').value,
            staff_id: staffId,
            email,
            phone: document.getElementById('u-phone').value.trim(),
        };
        if (password) data.password = password;

        if (user) {
            updateUser(user.user_id, data);
            showToast('Staff account updated');
        } else {
            addUser(Object.assign({ is_active: 1 }, data));
            showToast('Staff account created');
        }
        closeModal();
        renderUsers();
    });
}
