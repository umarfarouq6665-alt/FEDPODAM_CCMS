// ============================================================
// Appointments | modules/reception/appointment.html
// ============================================================

let apptFilter = 'all';

document.addEventListener('DOMContentLoaded', () => {
    requireRole(['Administrator', 'Receptionist']);
    if (!isLoggedIn()) return;
    renderLayout('Appointments');
    renderAppointments();

    document.getElementById('status-filter').addEventListener('click', (e) => {
        const chip = e.target.closest('.chip');
        if (!chip) return;
        document.querySelectorAll('#status-filter .chip').forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        apptFilter = chip.dataset.status;
        renderAppointments();
    });
});

function renderAppointments() {
    const tbody = document.getElementById('appt-body');
    let list = [...DB.appointments].sort((a, b) => (b.appt_date + b.appt_time).localeCompare(a.appt_date + a.appt_time));
    if (apptFilter !== 'all') list = list.filter(a => a.status === apptFilter);

    if (!list.length) {
        tbody.innerHTML = `<tr><td colspan="7"><div class="empty-state"><div class="empty-state-icon">📅</div><h3>No appointments found</h3></div></td></tr>`;
        return;
    }

    const statusClass = { Scheduled: 'badge-info', Attended: 'badge-success', Cancelled: 'badge-danger' };

    tbody.innerHTML = list.map(a => {
        const patient = findPatient(a.patient_id);
        const clinician = findUser(a.clinician_id);
        return `
        <tr>
            <td>${escapeHtml(patient ? patient.full_name : a.patient_id)}</td>
            <td>${escapeHtml(clinician ? clinician.full_name : '—')}</td>
            <td>${formatDate(a.appt_date)}</td>
            <td>${formatTime(a.appt_time)}</td>
            <td>${escapeHtml(a.reason || '—')}</td>
            <td><span class="badge ${statusClass[a.status] || 'badge-muted'}">${escapeHtml(a.status)}</span></td>
            <td>
                ${a.status === 'Scheduled' ? `
                    <div class="row-actions">
                        <button class="icon-btn" title="Mark attended" onclick="setApptStatus(${a.appt_id}, 'Attended')">✓</button>
                        <button class="icon-btn danger" title="Cancel" onclick="setApptStatus(${a.appt_id}, 'Cancelled')">✕</button>
                    </div>` : ''}
            </td>
        </tr>`;
    }).join('');
}

function setApptStatus(id, status) {
    updateAppointmentStatus(id, status);
    renderAppointments();
    showToast(`Appointment marked ${status}`);
}

function openBookingModal() {
    const patients = [...DB.patients].sort((a, b) => a.full_name.localeCompare(b.full_name));
    const clinicians = DB.users.filter(u => u.role === 'Clinician' && u.is_active);

    openModal(`
        <div class="modal-header">
            <span class="modal-title">Book Appointment</span>
            <button class="modal-close" onclick="closeModal()">✕</button>
        </div>
        <form id="booking-form">
            <div class="modal-body">
                <div id="booking-alert"></div>
                <div class="form-grid">
                    <div class="form-group full">
                        <label for="b-patient">Patient *</label>
                        <select id="b-patient" required>
                            <option value="">Select patient…</option>
                            ${patients.map(p => `<option value="${escapeHtml(p.patient_id)}">${escapeHtml(p.full_name)} (${escapeHtml(p.patient_id)})</option>`).join('')}
                        </select>
                    </div>
                    <div class="form-group full">
                        <label for="b-clinician">Clinician *</label>
                        <select id="b-clinician" required>
                            <option value="">Select clinician…</option>
                            ${clinicians.map(c => `<option value="${c.user_id}">${escapeHtml(c.full_name)}</option>`).join('')}
                        </select>
                        ${!clinicians.length ? '<div class="form-hint">No active clinicians found — add one from User Management first.</div>' : ''}
                    </div>
                    <div class="form-group"><label for="b-date">Date *</label><input type="date" id="b-date" required></div>
                    <div class="form-group"><label for="b-time">Time *</label><input type="time" id="b-time" required></div>
                    <div class="form-group full"><label for="b-reason">Reason</label><input type="text" id="b-reason" placeholder="e.g. Follow-up review"></div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-ghost" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-navy">Book Appointment</button>
            </div>
        </form>
    `);

    document.getElementById('booking-form').addEventListener('submit', (e) => {
        e.preventDefault();
        const patientId = document.getElementById('b-patient').value;
        const clinicianId = Number(document.getElementById('b-clinician').value);
        const date = document.getElementById('b-date').value;
        const time = document.getElementById('b-time').value;
        const reason = document.getElementById('b-reason').value.trim();

        if (!patientId || !clinicianId || !date || !time) {
            document.getElementById('booking-alert').innerHTML = `<div class="alert alert-danger">🚫 Please fill in all required fields.</div>`;
            return;
        }

        addAppointment({
            patient_id: patientId,
            clinician_id: clinicianId,
            appt_date: date,
            appt_time: time,
            reason,
            notes: '',
            created_by: currentUser().id,
        });

        closeModal();
        renderAppointments();
        showToast('Appointment booked');
    });
}
