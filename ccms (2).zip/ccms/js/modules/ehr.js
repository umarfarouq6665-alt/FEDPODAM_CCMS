// ============================================================
// Patient EHR | modules/clinician/patients.html
// ============================================================

document.addEventListener('DOMContentLoaded', () => {
    requireRole(['Administrator', 'Clinician']);
    if (!isLoggedIn()) return;
    renderLayout('Patient EHR');
    renderPatients();
    document.getElementById('search-input').addEventListener('input', renderPatients);
});

function lastVisit(patientId) {
    const list = DB.consultations
        .filter(c => c.patient_id === patientId)
        .sort((a, b) => new Date(b.consult_date) - new Date(a.consult_date));
    return list.length ? list[0].consult_date : null;
}

function renderPatients() {
    const query = document.getElementById('search-input').value.trim().toLowerCase();
    let list = [...DB.patients].sort((a, b) => a.full_name.localeCompare(b.full_name));
    if (query) {
        list = list.filter(p =>
            p.full_name.toLowerCase().includes(query) ||
            p.patient_id.toLowerCase().includes(query)
        );
    }

    const tbody = document.getElementById('patient-body');
    if (!list.length) {
        tbody.innerHTML = `<tr><td colspan="5"><div class="empty-state"><div class="empty-state-icon">🩺</div><h3>No patients found</h3></div></td></tr>`;
        return;
    }

    tbody.innerHTML = list.map(p => {
        const lv = lastVisit(p.patient_id);
        return `
        <tr>
            <td><span class="pid-code">${escapeHtml(p.patient_id)}</span></td>
            <td>${escapeHtml(p.full_name)}</td>
            <td><span class="badge badge-info">${escapeHtml(p.category)}</span></td>
            <td style="font-size:12px;color:var(--ink-600);">${lv ? formatDate(lv) : 'No visits yet'}</td>
            <td>
                <div class="row-actions">
                    <button class="btn btn-ghost btn-sm" onclick="viewHistory('${p.patient_id}')">History</button>
                    <button class="btn btn-navy btn-sm" onclick="openConsultModal('${p.patient_id}')">+ Consultation</button>
                </div>
            </td>
        </tr>`;
    }).join('');
}

function viewHistory(patientId) {
    const p = findPatient(patientId);
    const history = DB.consultations
        .filter(c => c.patient_id === patientId)
        .sort((a, b) => new Date(b.consult_date) - new Date(a.consult_date));

    openModal(`
        <div class="modal-header">
            <span class="modal-title">${escapeHtml(p.full_name)} — History</span>
            <button class="modal-close" onclick="closeModal()">✕</button>
        </div>
        <div class="modal-body">
            <div class="detail-grid" style="margin-bottom:18px;">
                <div><div class="detail-label">Allergies</div><div class="detail-value">${escapeHtml(p.allergies || 'None')}</div></div>
                <div><div class="detail-label">Blood Group</div><div class="detail-value">${escapeHtml(p.blood_group || '—')}</div></div>
            </div>
            ${history.length ? history.map(c => {
                const rx = DB.prescriptions.filter(r => r.consult_id === c.consult_id);
                return `
                <div style="padding:12px 0;border-bottom:1px solid var(--border-soft);">
                    <div style="display:flex;justify-content:space-between;align-items:baseline;gap:10px;">
                        <span style="font-weight:700;font-size:13.5px;color:var(--navy-900);">${escapeHtml(c.diagnosis)}</span>
                        <span style="font-size:11px;color:var(--ink-400);white-space:nowrap;">${formatDate(c.consult_date)}</span>
                    </div>
                    <div style="font-size:12.5px;color:var(--ink-600);margin-top:4px;">${escapeHtml(c.complaint)}</div>
                    <div style="font-size:11.5px;color:var(--ink-400);margin-top:6px;">Temp ${escapeHtml(c.temp || '—')} · BP ${escapeHtml(c.bp || '—')} · Pulse ${escapeHtml(c.pulse || '—')} · Weight ${escapeHtml(c.weight || '—')}</div>
                    ${c.referral ? `<div style="font-size:11.5px;color:var(--warning);margin-top:4px;">⚠ Referred: ${escapeHtml(c.referral_note || '—')}</div>` : ''}
                    ${c.follow_up ? `<div style="font-size:11.5px;color:var(--ink-600);margin-top:4px;">Follow-up: ${escapeHtml(c.follow_up)}</div>` : ''}
                    ${rx.length ? `<div style="margin-top:8px;">${rx.map(r => `<span class="badge ${r.dispensed ? 'badge-success' : 'badge-warning'}" style="margin:2px 4px 0 0;">${escapeHtml(r.drug_name)} · ${escapeHtml(r.dosage)}</span>`).join('')}</div>` : ''}
                </div>`;
            }).join('') : '<div class="empty-state"><div class="empty-state-icon">🩺</div><h3>No consultations recorded yet</h3></div>'}
        </div>
        <div class="modal-footer"><button class="btn btn-ghost" onclick="closeModal()">Close</button></div>
    `);
}

function openConsultModal(patientId) {
    const p = findPatient(patientId);

    openModal(`
        <div class="modal-header">
            <span class="modal-title">New Consultation — ${escapeHtml(p.full_name)}</span>
            <button class="modal-close" onclick="closeModal()">✕</button>
        </div>
        <form id="consult-form">
            <div class="modal-body">
                <div id="consult-alert"></div>
                <div class="form-grid">
                    <div class="form-group full"><label for="c-complaint">Chief Complaint *</label><textarea id="c-complaint" required></textarea></div>
                    <div class="form-group full"><label for="c-diagnosis">Diagnosis *</label><input type="text" id="c-diagnosis" required></div>
                    <div class="form-group"><label for="c-temp">Temperature</label><input type="text" id="c-temp" placeholder="e.g. 37.2°C"></div>
                    <div class="form-group"><label for="c-bp">Blood Pressure</label><input type="text" id="c-bp" placeholder="e.g. 120/80"></div>
                    <div class="form-group"><label for="c-pulse">Pulse</label><input type="text" id="c-pulse" placeholder="e.g. 78bpm"></div>
                    <div class="form-group"><label for="c-weight">Weight</label><input type="text" id="c-weight" placeholder="e.g. 68kg"></div>
                    <div class="form-group full checkbox-row"><input type="checkbox" id="c-referral"><label for="c-referral" style="margin:0;">Referral required</label></div>
                    <div class="form-group full"><label for="c-referral-note">Referral Note</label><input type="text" id="c-referral-note"></div>
                    <div class="form-group full"><label for="c-followup">Follow-up Instructions</label><input type="text" id="c-followup"></div>
                </div>

                <div style="margin-top:20px;">
                    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;">
                        <span class="detail-label" style="margin:0;">Prescriptions</span>
                        <button type="button" class="btn btn-ghost btn-sm" onclick="addRxLine()">+ Add Drug</button>
                    </div>
                    <div id="rx-lines"></div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-ghost" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-navy">Save Consultation</button>
            </div>
        </form>
    `, { className: 'modal-lg' });

    addRxLine();

    document.getElementById('consult-form').addEventListener('submit', (e) => {
        e.preventDefault();
        const complaint = document.getElementById('c-complaint').value.trim();
        const diagnosis = document.getElementById('c-diagnosis').value.trim();

        if (!complaint || !diagnosis) {
            document.getElementById('consult-alert').innerHTML = `<div class="alert alert-danger">🚫 Complaint and diagnosis are required.</div>`;
            return;
        }

        const prescriptions = [];
        document.querySelectorAll('.rx-line').forEach(row => {
            const drugName = row.querySelector('.rx-drug').value.trim();
            if (!drugName) return;
            prescriptions.push({
                drug_name: drugName,
                dosage: row.querySelector('.rx-dosage').value.trim(),
                frequency: row.querySelector('.rx-frequency').value.trim(),
                duration: row.querySelector('.rx-duration').value.trim(),
                qty_prescribed: parseInt(row.querySelector('.rx-qty').value, 10) || 1,
            });
        });

        addConsultation({
            patient_id: patientId,
            clinician_id: currentUser().id,
            complaint,
            diagnosis,
            temp: document.getElementById('c-temp').value.trim(),
            bp: document.getElementById('c-bp').value.trim(),
            pulse: document.getElementById('c-pulse').value.trim(),
            weight: document.getElementById('c-weight').value.trim(),
            referral: document.getElementById('c-referral').checked ? 1 : 0,
            referral_note: document.getElementById('c-referral-note').value.trim(),
            follow_up: document.getElementById('c-followup').value.trim(),
        }, prescriptions);

        closeModal();
        renderPatients();
        showToast('Consultation saved');
    });
}

let rxLineCount = 0;

function addRxLine() {
    rxLineCount++;
    const drugOptions = DB.pharmacy.map(d => `<option value="${escapeHtml(d.drug_name)}">`).join('');
    const wrap = document.getElementById('rx-lines');
    const row = document.createElement('div');
    row.className = 'rx-line';
    row.innerHTML = `
        <input class="rx-drug" list="drug-options-${rxLineCount}" placeholder="Drug name">
        <datalist id="drug-options-${rxLineCount}">${drugOptions}</datalist>
        <input class="rx-dosage" placeholder="Dosage">
        <input class="rx-frequency" placeholder="Frequency">
        <input class="rx-duration" placeholder="Duration">
        <input class="rx-qty" type="number" min="1" value="1">
        <button type="button" class="icon-btn danger" title="Remove" onclick="this.closest('.rx-line').remove()">✕</button>
    `;
    wrap.appendChild(row);
}
