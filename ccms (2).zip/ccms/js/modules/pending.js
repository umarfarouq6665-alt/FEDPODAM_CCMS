// ============================================================
// Pending Prescriptions | modules/pharmacy/pending.html
// ============================================================

document.addEventListener('DOMContentLoaded', () => {
    requireRole(['Administrator', 'Pharmacist']);
    if (!isLoggedIn()) return;
    renderLayout('Pending Prescriptions');
    renderPending();
});

function renderPending() {
    const tbody = document.getElementById('rx-body');
    const pending = DB.prescriptions
        .filter(r => !r.dispensed)
        .map(r => ({ rx: r, consult: DB.consultations.find(c => c.consult_id === r.consult_id) }))
        .sort((a, b) => new Date(b.consult ? b.consult.consult_date : 0) - new Date(a.consult ? a.consult.consult_date : 0));

    if (!pending.length) {
        tbody.innerHTML = `<tr><td colspan="8"><div class="empty-state"><div class="empty-state-icon">💊</div><h3>No pending prescriptions</h3></div></td></tr>`;
        return;
    }

    tbody.innerHTML = pending.map(({ rx, consult }) => {
        const patient = consult ? findPatient(consult.patient_id) : null;
        const stock = DB.pharmacy.find(d => d.drug_name === rx.drug_name);
        const short = stock && stock.qty_in_stock < rx.qty_prescribed;
        return `
        <tr>
            <td>${escapeHtml(patient ? patient.full_name : '—')}</td>
            <td>${escapeHtml(rx.drug_name)}</td>
            <td>${escapeHtml(rx.dosage)}</td>
            <td>${escapeHtml(rx.frequency)}</td>
            <td>${escapeHtml(rx.duration)}</td>
            <td>${rx.qty_prescribed}${short ? ' <span class="badge badge-danger">Low stock</span>' : ''}</td>
            <td style="font-size:12px;color:var(--ink-600);">${consult ? formatDate(consult.consult_date) : '—'}</td>
            <td><button class="btn btn-navy btn-sm" onclick="dispense(${rx.rx_id})">Dispense</button></td>
        </tr>`;
    }).join('');
}

function dispense(rxId) {
    dispensePrescription(rxId, currentUser().id);
    renderPending();
    showToast('Prescription dispensed');
}
